﻿using BikeStores.Data.Models;
using System.ComponentModel;

namespace BikeStores.Frontend.Models
{
    public class ProductDetailsViewModel
    {
        public int ProductId { get; set; }
        [DisplayName("Product")]
        public string ProductName { get; set; }
        [DisplayName("Brand")]
        public string BrandName { get; set; }
        [DisplayName("Category")]
        public string CategoryName { get; set; }
        [DisplayName("Price")]
        public decimal ListPrice { get; set; }
        [DisplayName("Production year")]
        public short ModelYear { get; set; }
        public int? Quantity { get; set; }

        public ProductDetailsViewModel(Stock s)
        {
            ProductId = s.Product.ProductId;
            ProductName = s.Product.ProductName;
            BrandName = s.Product.Brand.BrandName;
            CategoryName = s.Product.Category.CategoryName;
            ListPrice = s.Product.ListPrice;
            ModelYear = s.Product.ModelYear;
            Quantity = s.Quantity;
        }
    }
}
