

<?php $__env->startSection("title", $title); ?>

<?php $__env->startSection("content"); ?>
	<h1><?php echo e($title); ?></h1>

	<form action="" method="post">
		<input type="text" name="name" id="name" placeholder="name">
		<input type="email" name="email" id="email" placeholder="email">
		<input type="password" name="password" id="password" placeholder="password">
		<input type="submit" value="log in">
	</form>
	<a href="<?php echo e(route("user.register")); ?>" , role="button">registrati</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\samuele.querio\Documents\GitHub\its\php Laravel\lar2-esercitazione-budget-personale\resources\views/users/login.blade.php ENDPATH**/ ?>