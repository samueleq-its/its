

<?php $__env->startSection("title", $title); ?>

<?php $__env->startSection("content"); ?>

	<h1><?php echo e($title); ?></h1>

	<?php if($errors->any()): ?>
		<article>
			<strong>Correggi i seguenti errori:</strong>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</article>
	<?php endif; ?>

	<form method="POST" action="<?php echo e(route('transactions.store')); ?>" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>

		<label for="description">Descrizione</label>
		<input type="text" id="description" name="description" value="<?php echo e(old('description')); ?>" required>

		<label for="date">Data</label>
		<input type="date" id="date" name="date" value="<?php echo e(old('date')); ?>" required>

		<label for="amount">Importo</label>
		<input type="number" id="amount" name="amount" step="0.01" value="<?php echo e(old('amount')); ?>" required>

		<label for="category">Categoria</label>
		<select id="category" name="category" required>
			<option value="">Seleziona una categoria</option>
			<option value="Affitto" <?php if(old('category') === 'Affitto'): echo 'selected'; endif; ?>>Affitto</option>
			<option value="Stipendio" <?php if(old('category') === 'Stipendio'): echo 'selected'; endif; ?>>Stipendio</option>
			<option value="Spese Generali" <?php if(old('category') === 'Spese Generali'): echo 'selected'; endif; ?>>Spese Generali</option>
			<option value="Altro" <?php if(old('category') === 'Altro'): echo 'selected'; endif; ?>>Altro</option>
		</select>

		<label for="receipt">Ricevuta</label>
		<input type="file" id="receipt" name="receipt" accept="image/*,.pdf">

		<button type="submit">Salva transazione</button>
	</form>



<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\samuele.querio\Documents\GitHub\its\php Laravel\lar2-esercitazione-budget-personale\resources\views/transactions/create.blade.php ENDPATH**/ ?>