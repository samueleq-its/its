

<?php $__env->startSection("title", $title); ?>

<?php $__env->startSection("content"); ?>

	<h1><?php echo e($title); ?></h1>

	<a href="<?php echo e(route("transactions.create")); ?>" role="button">Nuova Transazione</a>

	<table>
		<thead>
			<th>Data</th>
			<th>Descrizione</th>
			<th>Importo</th>
			<th>Categoria</th>
			<th>Ricevute</th>
		</thead>
		<tbody>
			<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<tr>
					<td><?php echo e($transaction->date); ?></td>
					<td><?php echo e($transaction->description); ?></td>
					<td><?php echo e($transaction->amount); ?></td>
					<td><?php echo e($transaction->category); ?></td>
					<td><?php echo e($transaction->receipt); ?></td>
					<td><a href="" role="button">Modifica</a></td>
					<td>
						<form action="<?php echo e(route('transactions.destroy', $transaction->id)); ?>" method="post">
							<?php echo csrf_field(); ?>
							<?php echo method_field('DELETE'); ?>
							<button type="submit" role="button">X</button>
						</form>
					</td>

				</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\samuele.querio\Documents\GitHub\its\php Laravel\lar2-esercitazione-budget-personale\resources\views/transactions/index.blade.php ENDPATH**/ ?>