<nav>
	<ul>
		<li><strong>ITS</strong></li>
	</ul>
	<ul>
		<li><a href="<?php echo e(route("transactions.index")); ?>">Transazioni</a></li>
		<li><a href="<?php echo e(route("logins.login")); ?>">Login</a></li>
		<li><a href="#">???</a></li>
	</ul>
</nav><?php /**PATH C:\Users\samuele.querio\Documents\GitHub\its\php Laravel\lar2-esercitazione-budget-personale\resources\views/layouts/menu.blade.php ENDPATH**/ ?>