<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo $__env->yieldContent("title"); ?></title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
</head>

<body>

	<?php echo $__env->make('layouts.menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

	<div class="container">
		<?php echo $__env->yieldContent("content"); ?>
	</div>
</body>

</html><?php /**PATH C:\Users\samuele.querio\Documents\GitHub\its\php Laravel\lar2-esercitazione-budget-personale\resources\views/layouts/app.blade.php ENDPATH**/ ?>