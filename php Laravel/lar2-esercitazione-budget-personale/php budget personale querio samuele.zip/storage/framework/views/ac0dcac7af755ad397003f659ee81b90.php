

<?php $__env->startSection("title", $title); ?>

<?php $__env->startSection("content"); ?>
	<h1><?php echo e($title); ?></h1>

	<form action="<?php echo e(route("logins.store")); ?>" method="post">
		<?php echo csrf_field(); ?>
		<input type="text" name="name" id="name" placeholder="name">
		<input type="email" name="email" id="email" placeholder="email">
		<input type="password" name="password" id="password" placeholder="password">
		<input type="submit" value="registrati">
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\samuele.querio\Documents\GitHub\its\php Laravel\lar2-esercitazione-budget-personale\resources\views/logins/register.blade.php ENDPATH**/ ?>